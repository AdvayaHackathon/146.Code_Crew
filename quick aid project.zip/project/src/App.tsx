import React, { useState } from 'react';
import { Menu, X, Heart, Scan, Guitar as Hospital, MessageSquare } from 'lucide-react';
import ScanHarm from './components/ScanHarm';
import BLS from './components/BLS';
import NearbyHospital from './components/NearbyHospital';
import AIChat from './components/AIChat';

function App() {
  const [activeTab, setActiveTab] = useState('scan');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const tabs = [
    { id: 'scan', name: 'Scan the Harm', icon: Scan },
    { id: 'bls', name: 'BLS', icon: Heart },
    { id: 'hospital', name: 'Find Hospital', icon: Hospital },
    { id: 'chat', name: 'AI Chat', icon: MessageSquare },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-red-600 text-white shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold">Quick-Aid</h1>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            <nav className="hidden md:flex space-x-6">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                    activeTab === tab.id
                      ? 'bg-red-700'
                      : 'hover:bg-red-500'
                  }`}
                >
                  <tab.icon size={20} />
                  <span>{tab.name}</span>
                </button>
              ))}
            </nav>
          </div>
          {/* Mobile menu */}
          {isMenuOpen && (
            <nav className="mt-4 md:hidden">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    setIsMenuOpen(false);
                  }}
                  className={`flex items-center space-x-2 w-full px-4 py-3 rounded-lg transition-colors ${
                    activeTab === tab.id
                      ? 'bg-red-700'
                      : 'hover:bg-red-500'
                  }`}
                >
                  <tab.icon size={20} />
                  <span>{tab.name}</span>
                </button>
              ))}
            </nav>
          )}
        </div>
      </header>

      {/* Main content */}
      <main className="container mx-auto px-4 py-8">
        {activeTab === 'scan' && <ScanHarm />}
        {activeTab === 'bls' && <BLS />}
        {activeTab === 'hospital' && <NearbyHospital />}
        {activeTab === 'chat' && <AIChat />}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-6">
        <div className="container mx-auto px-4 text-center">
          <p>© 2025 Quick-Aid Emergency Help. For emergencies, call 108.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;