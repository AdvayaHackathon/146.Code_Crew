import React, { useState, useEffect } from 'react';
import {
  Heart,
  Phone,
  AlertTriangle,
  CheckCircle,
  Clock,
  Volume2,
  VolumeX,
  ChevronRight
} from 'lucide-react';

type PatientType = 'adult' | 'child' | 'infant';
type AssessmentStep = 'initial' | 'breathing' | 'pulse' | 'cpr' | 'recovery';

function BLS() {
  const [patientType, setPatientType] = useState<PatientType>('adult');
  const [currentStep, setCurrentStep] = useState<AssessmentStep>('initial');
  const [isCountingDown, setIsCountingDown] = useState(false);
  const [compressionCount, setCompressionCount] = useState(0);
  const [audioEnabled, setAudioEnabled] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isCountingDown && compressionCount < 30) {
      interval = setInterval(() => {
        setCompressionCount(count => count + 1);
        if (audioEnabled) {
          // Play metronome sound
          const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBkCU1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBTqO0/HPgDMGHm7A7+OZRA0PVqzn77BdGAg+ltryxnYpBSh8yu7blEILFlyx6OyrWBUIQ5zd8sFuJAU3jNDwzYI2Bhxqvu7mnEcODlOq5O+zYBoIPJPY8sp5LQUme8nv3ZdFDBVZr+ftrVoXCECY3PLEcSYFNYnO8NCENQYbarvu55xIDg1QqOPwtGIdCDqQ1vLNfDAFJHfH8d+aRw0UV63l765dGQc+ldrzyHQoBTOHzPDShjcHGWe57uihSxAMTaXi8bZlHwc4jdTy0H4yBSF0xe/hmUgOElWq5PCwYBoGPJLY88p6KwUyhMrw1Ig4BxdktO7qpE0RC0ui4PG4aCAHNorS8tOANQUfccTw45tKDhBTqOPxsmIcBjqP1vLMfS0FMIHl8dSJOQcWYrLt7KZOEglIn97yvGohBzSIz/LVgjcFHW/C7+WdTA4OU6bh8bRkHQY4jNTy0n8vBS6B5PPVijsHFWCw7e6oUBIIRp3e872sIwYyhc3y14Q4BR1sw+/mnk4PDFGk4fK2Zh4GNo3Y8tOAMQUugOPz14w8BxNesO3wqlISB0Sb3vPArCQGMYTM89iGOgUca8Hv6KBQDwtOpODzuGgfBjWK1PLVgjIFLH7i89mOPgcSXK/t8axUEwZCmN7zw64mBi+CyvPahzwFGmnA7+qiURAKTKLf87ppIAYziNLy14Q0BSt+4fPbkEAHEVqu7fKtVxQFQJbc88WvJwYug8nz3Ig9BRlnv+/ro1IQCkqg3/S8ayIGMYbQ8tmGNgUpfODz3ZJBBxBYrO30r1kUBT6V2/PHsSkFLIHH892KPwUYZb3v7aVUEQlIn97yvm0jBi+EzvPbiDgFKHre896TQwcPVqrt9LFaFQU8k9rzyrEqBSp/xvPfiz/GF2O87++nVhEISJ3e88BuJQYtgszz34o5BSZ63PPglEUHDlSp7PayXBUEOpDY886zLAUofcTz4Y1AxhVhuu7xqVgSBkab3vPCcCYGK4DL8+GMOwUleNrz45ZGBw1Sp+71tF4WBDiO1vPQtS4FJ3vD8+OOQcYUX7jt86tbEgZEmN3zxHInBil+yfPjjTwFJHbY8+WYSAcMUKXu9rZgFgM2i9Tz0rcwBSV5wfPkj0TGEl237vSuXRMFQpbc88dzKQYnfMjz5Y8+BSJ01/PnmkoHDE6j7ve4YhcDNYnS89S5MgUjd7/z55FExhFbtO73sF8TBECTs/PJdSoGJnrG8+eRQAUgctXz6ZxMBwtMoe74umQYAzOG0PPWujQFIXW98+mTRsYQWbLu+LJgFAM+kLHz2nctBiR4xPPpk0IFH3DU8+ueTgcLS5/u+bxmGQIxhM7z2Lw2BSB0vPPqlEjGD1ix7vm0YhUDPY6v89x5LwYidMLz65VDBh1u0vPsnlAHCkme7vq+aBoCL4HN89q+OAUec7vz7JZJxg5Wr+76tmQWAjuMrfPefTEGIHK/8+2XRAYcbNDz7aBRBwhInO77wWwbAi5/y/PcwDoFHXG58+6YS8YNVK3u+7hmFwI6iavz34E0Bh5wvPPumEUGG2rO8+2iUwcHRpru/MNuHQIrfMnz38M6BR1wuPPvm0zGDFKr7vy6aRgCOYiq8+GCNQYdb7nz8JpHBhpozPPvo1UHBkWY7vzEbh4CKHrI8+HFPAUcbrbz8ZxNxgtSqO79vGsZAjiGqPPihDYGHG238/GdSQYZaMvz8aVXBwVEluz8xnAgAiZ5x/Pi');
          audio.play();
        }
      }, 500); // 120 BPM = 1 compression every 500ms
    }
    return () => clearInterval(interval);
  }, [isCountingDown, compressionCount, audioEnabled]);

  const startCPR = () => {
    setIsCountingDown(true);
    setCompressionCount(0);
  };

  const stopCPR = () => {
    setIsCountingDown(false);
    setCompressionCount(0);
  };

  const emergencyCall = () => {
    window.location.href = 'tel:108';
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
          <Heart className="text-red-600 mr-2" />
          Basic Life Support (BLS)
        </h2>

        {/* Emergency Call Button */}
        <button
          onClick={emergencyCall}
          className="w-full mb-6 bg-red-600 text-white py-4 rounded-lg flex items-center justify-center text-lg font-semibold hover:bg-red-700"
        >
          <Phone className="mr-2" />
          Call Emergency (108)
        </button>

        {/* Patient Type Selection */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-3">Select Patient Type:</h3>
          <div className="grid grid-cols-3 gap-4">
            {(['adult', 'child', 'infant'] as PatientType[]).map(type => (
              <button
                key={type}
                onClick={() => setPatientType(type)}
                className={`py-2 px-4 rounded-lg ${
                  patientType === type
                    ? 'bg-red-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {type.charAt(0).toUpperCase() + type.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Assessment Flow */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-3">Emergency Assessment:</h3>
          <div className="space-y-4">
            {currentStep === 'initial' && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <h4 className="font-semibold flex items-center">
                  <AlertTriangle className="text-yellow-600 mr-2" />
                  Check Scene Safety
                </h4>
                <ul className="mt-2 space-y-2">
                  <li className="flex items-center">
                    <ChevronRight className="text-yellow-600 mr-2" size={16} />
                    Ensure the area is safe for you and the victim
                  </li>
                  <li className="flex items-center">
                    <ChevronRight className="text-yellow-600 mr-2" size={16} />
                    Check for responsiveness
                  </li>
                </ul>
                <button
                  onClick={() => setCurrentStep('breathing')}
                  className="mt-4 bg-yellow-600 text-white py-2 px-4 rounded hover:bg-yellow-700"
                >
                  Area is Safe - Continue
                </button>
              </div>
            )}

            {currentStep === 'breathing' && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-semibold">Check Breathing</h4>
                <p className="mt-2">Look, listen, and feel for breathing for 10 seconds</p>
                <div className="mt-4 space-x-4">
                  <button
                    onClick={() => setCurrentStep('recovery')}
                    className="bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700"
                  >
                    Normal Breathing
                  </button>
                  <button
                    onClick={() => setCurrentStep('pulse')}
                    className="bg-red-600 text-white py-2 px-4 rounded hover:bg-red-700"
                  >
                    No/Abnormal Breathing
                  </button>
                </div>
              </div>
            )}

            {currentStep === 'pulse' && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <h4 className="font-semibold">Check Pulse</h4>
                <p className="mt-2">Check for pulse for 10 seconds</p>
                <div className="mt-4 space-x-4">
                  <button
                    onClick={() => setCurrentStep('breathing')}
                    className="bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700"
                  >
                    Pulse Present
                  </button>
                  <button
                    onClick={() => setCurrentStep('cpr')}
                    className="bg-red-600 text-white py-2 px-4 rounded hover:bg-red-700"
                  >
                    No Pulse - Start CPR
                  </button>
                </div>
              </div>
            )}

            {currentStep === 'cpr' && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <h4 className="font-semibold">Perform CPR</h4>
                <div className="mt-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <Clock className="mr-2" />
                      <span>Compressions: {compressionCount}/30</span>
                    </div>
                    <button
                      onClick={() => setAudioEnabled(!audioEnabled)}
                      className="p-2 rounded-full hover:bg-red-100"
                    >
                      {audioEnabled ? <Volume2 /> : <VolumeX />}
                    </button>
                  </div>
                  {!isCountingDown ? (
                    <button
                      onClick={startCPR}
                      className="w-full bg-red-600 text-white py-3 rounded-lg hover:bg-red-700"
                    >
                      Start Compressions
                    </button>
                  ) : (
                    <button
                      onClick={stopCPR}
                      className="w-full bg-gray-600 text-white py-3 rounded-lg hover:bg-gray-700"
                    >
                      Stop Compressions
                    </button>
                  )}
                </div>
              </div>
            )}

            {currentStep === 'recovery' && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <h4 className="font-semibold flex items-center">
                  <CheckCircle className="text-green-600 mr-2" />
                  Recovery Position
                </h4>
                <p className="mt-2">
                  Place the person in the recovery position and monitor breathing
                </p>
                <button
                  onClick={() => setCurrentStep('initial')}
                  className="mt-4 bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700"
                >
                  Restart Assessment
                </button>
              </div>
            )}
          </div>
        </div>

        {/* CPR Instructions */}
        <div className="mt-6 bg-gray-50 rounded-lg p-4">
          <h3 className="text-lg font-semibold mb-3">CPR Guidelines:</h3>
          <ul className="space-y-2">
            <li>Push hard and fast in the center of the chest</li>
            <li>Allow complete chest recoil after each compression</li>
            <li>Minimize interruptions in compressions</li>
            <li>Give rescue breaths if trained</li>
            <li>Switch compressors every 2 minutes if possible</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default BLS;