import React, { useState, useEffect } from 'react';
import { MapPin, Phone, Clock, AlertTriangle } from 'lucide-react';

interface Hospital {
  id: string;
  name: string;
  distance: number;
  waitTime: number;
  phone: string;
  address: string;
  specialties: string[];
  emergency: boolean;
}

// Mock data for hospitals
const mockHospitals: Hospital[] = [
  {
    id: '1',
    name: 'City General Hospital',
    distance: 1.2,
    waitTime: 15,
    phone: '080-2222-1111',
    address: '123 Healthcare Ave, Bangalore',
    specialties: ['Emergency Care', 'Trauma', 'Critical Care'],
    emergency: true
  },
  {
    id: '2',
    name: 'Apollo Hospital',
    distance: 2.5,
    waitTime: 30,
    phone: '080-3333-2222',
    address: '456 Medical Lane, Bangalore',
    specialties: ['Emergency Care', 'Cardiology', 'Neurology'],
    emergency: true
  },
  {
    id: '3',
    name: 'Fortis Healthcare',
    distance: 3.8,
    waitTime: 20,
    phone: '080-4444-3333',
    address: '789 Health Street, Bangalore',
    specialties: ['Emergency Care', 'Orthopedics', 'Surgery'],
    emergency: true
  }
];

function NearbyHospital() {
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSpecialty, setSelectedSpecialty] = useState('all');
  const [userLocation, setUserLocation] = useState<GeolocationPosition | null>(null);

  useEffect(() => {
    // Simulate fetching hospitals based on user's location
    const fetchHospitals = async () => {
      setLoading(true);
      // Get user's location
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            setUserLocation(position);
            // Simulate API call with mock data
            setTimeout(() => {
              setHospitals(mockHospitals);
              setLoading(false);
            }, 1000);
          },
          (error) => {
            console.error('Error getting location:', error);
            setHospitals(mockHospitals);
            setLoading(false);
          }
        );
      } else {
        setHospitals(mockHospitals);
        setLoading(false);
      }
    };

    fetchHospitals();
  }, []);

  const getWaitTimeColor = (minutes: number) => {
    if (minutes <= 15) return 'text-green-600';
    if (minutes <= 30) return 'text-yellow-600';
    return 'text-red-600';
  };

  const handleCall = (phone: string) => {
    window.location.href = `tel:${phone}`;
  };

  const handleNavigation = (address: string) => {
    if (userLocation) {
      const { latitude, longitude } = userLocation.coords;
      window.open(
        `https://www.google.com/maps/dir/${latitude},${longitude}/${encodeURIComponent(address)}`,
        '_blank'
      );
    } else {
      window.open(
        `https://www.google.com/maps/search/${encodeURIComponent(address)}`,
        '_blank'
      );
    }
  };

  const filteredHospitals = selectedSpecialty === 'all'
    ? hospitals
    : hospitals.filter(hospital => 
        hospital.specialties.includes(selectedSpecialty)
      );

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
          <MapPin className="text-red-600 mr-2" />
          Nearby Hospitals
        </h2>

        {/* Emergency Notice */}
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
          <div className="flex items-start">
            <AlertTriangle className="text-red-600 mr-3 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-red-600">Emergency?</h3>
              <p className="text-red-700 mt-1">
                Call 108 immediately for emergency medical services
              </p>
            </div>
          </div>
        </div>

        {/* Specialty Filter */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Filter by Specialty:
          </label>
          <select
            value={selectedSpecialty}
            onChange={(e) => setSelectedSpecialty(e.target.value)}
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
          >
            <option value="all">All Specialties</option>
            <option value="Emergency Care">Emergency Care</option>
            <option value="Trauma">Trauma</option>
            <option value="Critical Care">Critical Care</option>
            <option value="Cardiology">Cardiology</option>
            <option value="Neurology">Neurology</option>
            <option value="Orthopedics">Orthopedics</option>
          </select>
        </div>

        {/* Hospital List */}
        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Finding nearby hospitals...</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredHospitals.map(hospital => (
              <div
                key={hospital.id}
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800">
                      {hospital.name}
                    </h3>
                    <p className="text-gray-600 text-sm mt-1">
                      {hospital.address}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleCall(hospital.phone)}
                      className="bg-green-600 text-white p-2 rounded-lg hover:bg-green-700"
                    >
                      <Phone size={20} />
                    </button>
                    <button
                      onClick={() => handleNavigation(hospital.address)}
                      className="bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700"
                    >
                      <MapPin size={20} />
                    </button>
                  </div>
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  {hospital.specialties.map(specialty => (
                    <span
                      key={specialty}
                      className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-sm"
                    >
                      {specialty}
                    </span>
                  ))}
                </div>

                <div className="mt-4 flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <MapPin size={16} className="text-gray-400 mr-1" />
                    <span>{hospital.distance} km away</span>
                  </div>
                  <div className="flex items-center">
                    <Clock size={16} className="mr-1" />
                    <span className={getWaitTimeColor(hospital.waitTime)}>
                      ~{hospital.waitTime} min wait
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default NearbyHospital;