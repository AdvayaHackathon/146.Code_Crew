import React, { useState, useRef, useEffect } from 'react';
import { Send, Globe, AlertTriangle } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  language: string;
  timestamp: Date;
  analysis?: {
    condition: string;
    severity: 'mild' | 'moderate' | 'severe';
    firstAid: string[];
    medications?: string[];
    seekMedicalAttention: boolean;
  };
}

const languages = [
  { code: 'en', name: 'English' },
  { code: 'kn', name: 'ಕನ್ನಡ' },
  { code: 'hi', name: 'हिंदी' },
  { code: 'ta', name: 'தமிழ்' },
  { code: 'te', name: 'తెలుగు' },
  { code: 'ml', name: 'മലയാളം' }
];

// Mock medical database for demo
const medicalDatabase = {
  'fever': {
    en: {
      condition: 'Fever',
      firstAid: [
        'Rest and stay hydrated',
        'Take lukewarm bath',
        'Use light clothing and bedding'
      ],
      medications: [
        'Paracetamol 500mg every 6 hours if temperature above 38.5°C',
        'Avoid aspirin in children'
      ]
    },
    kn: {
      condition: 'ಜ್ವರ',
      firstAid: [
        'ವಿಶ್ರಾಂತಿ ಮತ್ತು ನೀರು ಕುಡಿಯಿರಿ',
        'ಕೊಳಕು ಸ್ನಾನ ಮಾಡಿ',
        'ಹಗುರವಾದ ಬಟ್ಟೆ ಮತ್ತು ಹಾಸಿಗೆ ಬಳಸಿ'
      ],
      medications: [
        'ಪಾರಾಸಿಟಮಾಲ್ 500mg ಪ್ರತಿ 6 ಗಂಟೆಗೊಮ್ಮೆ ತಾಪಮಾನ 38.5°C ಮೇಲಿದ್ದರೆ',
        'ಮಕ್ಕಳಿಗೆ ಆಸ್ಪಿರಿನ್ ನೀಡಬೇಡಿ'
      ]
    }
  },
  'headache': {
    en: {
      condition: 'Headache',
      firstAid: [
        'Rest in a quiet, dark room',
        'Apply cold or warm compress',
        'Stay hydrated'
      ],
      medications: [
        'Paracetamol or Ibuprofen as directed',
        'Avoid caffeine'
      ]
    },
    kn: {
      condition: 'ತಲೆನೋವು',
      firstAid: [
        'ಶಾಂತ, ಕತ್ತಲೆ ಕೋಣೆಯಲ್ಲಿ ವಿಶ್ರಾಂತಿ ಪಡೆಯಿರಿ',
        'ತಣ್ಣನೆಯ ಅಥವಾ ಬೆಚ್ಚಗಿನ ಒತ್ತಡ ಹಾಕಿ',
        'ನೀರು ಕುಡಿಯಿರಿ'
      ],
      medications: [
        'ಪಾರಾಸಿಟಮಾಲ್ ಅಥವಾ ಐಬುಪ್ರೋಫೆನ್ ನಿರ್ದೇಶಿಸಿದಂತೆ',
        'ಕ್ಯಾಫೀನ್ ತಪ್ಪಿಸಿ'
      ]
    }
  }
};

function AIChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const analyzeSymptoms = (text: string): Message['analysis'] | undefined => {
    const symptoms = text.toLowerCase();
    let analysis;

    if (symptoms.includes('fever') || symptoms.includes('ಜ್ವರ')) {
      analysis = medicalDatabase['fever'][selectedLanguage as keyof typeof medicalDatabase['fever']];
    } else if (symptoms.includes('headache') || symptoms.includes('ತಲೆನೋವು')) {
      analysis = medicalDatabase['headache'][selectedLanguage as keyof typeof medicalDatabase['headache']];
    }

    if (analysis) {
      return {
        condition: analysis.condition,
        severity: 'moderate',
        firstAid: analysis.firstAid,
        medications: analysis.medications,
        seekMedicalAttention: false
      };
    }

    return undefined;
  };

  const simulateAIResponse = async (userMessage: string) => {
    setIsTyping(true);
    await new Promise(resolve => setTimeout(resolve, 1000));

    const analysis = analyzeSymptoms(userMessage);
    let response = selectedLanguage === 'en' 
      ? "I'm here to help. Please describe your symptoms or medical concern."
      : "ನಾನು ಸಹಾಯ ಮಾಡಲು ಇಲ್ಲಿದ್ದೇನೆ. ದಯವಿಟ್ಟು ನಿಮ್ಮ ರೋಗಲಕ್ಷಣಗಳನ್ನು ವಿವರಿಸಿ.";

    if (analysis) {
      response = selectedLanguage === 'en'
        ? `Based on your symptoms, you may have ${analysis.condition}. Here are some first aid steps and recommendations:`
        : `ನಿಮ್ಮ ರೋಗಲಕ್ಷಣಗಳ ಆಧಾರದಲ್ಲಿ, ನಿಮಗೆ ${analysis.condition} ಇರಬಹುದು. ಇಲ್ಲಿ ಕೆಲವು ಪ್ರಥಮ ಚಿಕಿತ್ಸೆ ಹಂತಗಳು ಮತ್ತು ಶಿಫಾರಸುಗಳಿವೆ:`;
    }

    setMessages(prev => [...prev, {
      id: Date.now().toString(),
      text: response,
      sender: 'ai',
      language: selectedLanguage,
      timestamp: new Date(),
      analysis
    }]);
    setIsTyping(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
      language: selectedLanguage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    await simulateAIResponse(input);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        {/* Header */}
        <div className="bg-red-600 text-white p-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">AI Health Assistant</h2>
            <div className="flex items-center">
              <Globe className="mr-2" size={20} />
              <select
                value={selectedLanguage}
                onChange={(e) => setSelectedLanguage(e.target.value)}
                className="bg-red-700 text-white rounded px-2 py-1 outline-none"
              >
                {languages.map(lang => (
                  <option key={lang.code} value={lang.code}>
                    {lang.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="h-[500px] overflow-y-auto p-4 space-y-4">
          {messages.map(message => (
            <div
              key={message.id}
              className={`flex ${
                message.sender === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.sender === 'user'
                    ? 'bg-red-600 text-white'
                    : 'bg-gray-100 text-gray-800'
                }`}
              >
                <p>{message.text}</p>
                {message.analysis && (
                  <div className="mt-4 space-y-4">
                    <div>
                      <h4 className="font-medium">
                        {selectedLanguage === 'en' ? 'First Aid Steps:' : 'ಪ್ರಥಮ ಚಿಕಿತ್ಸೆ ಹಂತಗಳು:'}
                      </h4>
                      <ul className="mt-2 space-y-1 list-disc list-inside">
                        {message.analysis.firstAid.map((step, index) => (
                          <li key={index}>{step}</li>
                        ))}
                      </ul>
                    </div>
                    {message.analysis.medications && (
                      <div>
                        <h4 className="font-medium">
                          {selectedLanguage === 'en' ? 'Recommended Medications:' : 'ಶಿಫಾರಸು ಮಾಡಿದ ಔಷಧಿಗಳು:'}
                        </h4>
                        <ul className="mt-2 space-y-1 list-disc list-inside">
                          {message.analysis.medications.map((med, index) => (
                            <li key={index}>{med}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {message.analysis.seekMedicalAttention && (
                      <div className="flex items-start mt-2 text-red-600">
                        <AlertTriangle className="mr-2 flex-shrink-0" />
                        <p>
                          {selectedLanguage === 'en'
                            ? 'Please seek immediate medical attention.'
                            : 'ದಯವಿಟ್ಟು ತಕ್ಷಣ ವೈದ್ಯಕೀಯ ಸಹಾಯ ಪಡೆಯಿರಿ.'}
                        </p>
                      </div>
                    )}
                  </div>
                )}
                <div className="text-xs mt-1 opacity-70">
                  {message.timestamp.toLocaleTimeString()}
                </div>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-gray-100 rounded-lg p-3">
                <div className="flex space-x-2">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <form onSubmit={handleSubmit} className="p-4 border-t">
          <div className="flex space-x-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={selectedLanguage === 'en' ? "Describe your symptoms..." : "ನಿಮ್ಮ ರೋಗಲಕ್ಷಣಗಳನ್ನು ವಿವರಿಸಿ..."}
              className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:border-red-500"
            />
            <button
              type="submit"
              className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700"
            >
              <Send size={20} />
            </button>
          </div>
        </form>

        {/* Disclaimer */}
        <div className="p-4 bg-gray-50 text-sm text-gray-600">
          <p>
            {selectedLanguage === 'en'
              ? 'This AI assistant provides general information only. For emergencies, please call 108 or visit the nearest hospital.'
              : 'ಈ AI ಸಹಾಯಕ ಸಾಮಾನ್ಯ ಮಾಹಿತಿಯನ್ನು ಮಾತ್ರ ನೀಡುತ್ತದೆ. ತುರ್ತು ಪರಿಸ್ಥಿತಿಗಳಿಗೆ, ದಯವಿಟ್ಟು 108 ಕ್ಕೆ ಕರೆ ಮಾಡಿ ಅಥವಾ ಹತ್ತಿರದ ಆಸ್ಪತ್ರೆಗೆ ಭೇಟಿ ನೀಡಿ.'}
          </p>
        </div>
      </div>
    </div>
  );
}

export default AIChat;