import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, X, AlertTriangle, CheckCircle } from 'lucide-react';
import Tesseract from 'tesseract.js';
import { BrowserMultiFormatReader } from '@zxing/library';

interface InjuryAnalysis {
  type: string;
  severity: 'low' | 'medium' | 'high';
  confidence: number;
  firstAid: string[];
  needsHospital: boolean;
}

const mockAnalyzeImage = async (image: File): Promise<InjuryAnalysis> => {
  // Simulated ML analysis
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // Mock analysis result
  return {
    type: 'Second Degree Burn',
    severity: 'medium',
    confidence: 0.89,
    firstAid: [
      'Cool the burn under cold running water for at least 10 minutes',
      'Remove any jewelry or tight clothing near the burn',
      'Cover with sterile, non-stick bandage',
      'Do not apply ice directly',
      'Do not pop any blisters'
    ],
    needsHospital: true
  };
};

function ScanHarm() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<InjuryAnalysis | null>(null);
  const [scanMode, setScanMode] = useState<'injury' | 'qr'>('injury');
  const [error, setError] = useState<string>('');

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    setFile(file);
    setPreview(URL.createObjectURL(file));
    setLoading(true);
    setError('');
    setResult(null);

    try {
      if (scanMode === 'injury') {
        const analysis = await mockAnalyzeImage(file);
        setResult(analysis);
      } else {
        // QR/Barcode scanning
        const reader = new BrowserMultiFormatReader();
        const img = new Image();
        img.src = URL.createObjectURL(file);
        await img.decode();
        const result = await reader.decodeFromImage(img);
        
        // Also perform OCR
        const { data: { text } } = await Tesseract.recognize(img.src);
        
        // Combine results
        setResult({
          type: 'Scanned Data',
          severity: 'low',
          confidence: 1,
          firstAid: [
            `QR/Barcode content: ${result?.text || 'No QR code found'}`,
            `OCR Text: ${text || 'No text detected'}`
          ],
          needsHospital: false
        });
      }
    } catch (err) {
      setError('Failed to analyze image. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [scanMode]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg']
    },
    maxFiles: 1
  });

  const reset = () => {
    setFile(null);
    setPreview('');
    setResult(null);
    setError('');
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'text-green-600';
      case 'medium': return 'text-yellow-600';
      case 'high': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Scan the Harm</h2>
        <div className="flex gap-4 mb-4">
          <button
            onClick={() => setScanMode('injury')}
            className={`px-4 py-2 rounded-lg ${
              scanMode === 'injury'
                ? 'bg-red-600 text-white'
                : 'bg-gray-200 text-gray-700'
            }`}
          >
            Injury Scanner
          </button>
          <button
            onClick={() => setScanMode('qr')}
            className={`px-4 py-2 rounded-lg ${
              scanMode === 'qr'
                ? 'bg-red-600 text-white'
                : 'bg-gray-200 text-gray-700'
            }`}
          >
            QR/Text Scanner
          </button>
        </div>
      </div>

      {!file && (
        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
            isDragActive ? 'border-red-500 bg-red-50' : 'border-gray-300 hover:border-red-500'
          }`}
        >
          <input {...getInputProps()} />
          <Upload className="mx-auto h-12 w-12 text-gray-400" />
          <p className="mt-2 text-gray-600">
            Drag & drop an image here, or click to select
          </p>
          <p className="text-sm text-gray-500">
            Supported formats: PNG, JPG, JPEG
          </p>
        </div>
      )}

      {file && (
        <div className="space-y-6">
          <div className="relative">
            <img
              src={preview}
              alt="Preview"
              className="w-full rounded-lg shadow-lg"
            />
            <button
              onClick={reset}
              className="absolute top-2 right-2 p-2 bg-red-600 text-white rounded-full hover:bg-red-700"
            >
              <X size={20} />
            </button>
          </div>

          {loading && (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600 mx-auto"></div>
              <p className="mt-4 text-gray-600">Analyzing image...</p>
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start">
              <AlertTriangle className="text-red-600 mr-3 flex-shrink-0" />
              <p className="text-red-600">{error}</p>
            </div>
          )}

          {result && (
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-semibold">{result.type}</h3>
                <div className={`flex items-center ${getSeverityColor(result.severity)}`}>
                  <CheckCircle className="mr-2" />
                  <span className="font-medium">
                    {result.confidence * 100}% confidence
                  </span>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-gray-700 mb-2">First Aid Steps:</h4>
                  <ul className="list-disc list-inside space-y-2">
                    {result.firstAid.map((step, index) => (
                      <li key={index} className="text-gray-600">{step}</li>
                    ))}
                  </ul>
                </div>

                {result.needsHospital && (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <p className="text-red-600 font-medium">
                      Medical attention recommended. Please visit the nearest hospital.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default ScanHarm;